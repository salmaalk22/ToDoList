package com.example.projectsalma

data class Model(
    val Id: String? = null,
    val Icon: String? = null,
    val Title: String? = null,
    val Description: String? = null,
)